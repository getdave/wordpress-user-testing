import { useEffect } from '@wordpress/element';
import { CanvasSubmenu } from './canvas-menu';
import { Menu } from './core-menu';
import {
	IMAGE_SHAPES,
	shapePath,
	preferredShapeRatio,
} from './image-shapes.mjs';

function ShapeIcon( { shape } ) {
	const ratio = preferredShapeRatio( shape ) || 1;
	const x = Math.max( 0, ( 100 - 100 * ratio ) / 2 ),
		y = Math.max( 0, ( 100 - 100 / ratio ) / 2 );
	return (
		<svg
			viewBox="0 0 100 100"
			width="24"
			height="24"
			aria-hidden="true"
			focusable="false"
		>
			<path
				d={ shapePath( shape ) }
				fill="currentColor"
				transform={ `translate(${ x } ${ y }) scale(${ 1 - x / 50 } ${ 1 - y / 50 })` }
			/>
			{ shape === 'none' && (
				<path d="M10 90L90 10" stroke="white" strokeWidth="8" />
			) }
		</svg>
	);
}

function useShapePreviewCleanup( clientId, clearShapePreview ) {
	useEffect(
		() => () => clearShapePreview(),
		[ clientId, clearShapePreview ]
	);
}

export function ImageShapeMenu( {
	clientId,
	shape,
	editable,
	changeShape,
	previewShape,
	clearShapePreview,
} ) {
	useShapePreviewCleanup( clientId, clearShapePreview );
	return (
		<CanvasSubmenu
			onOpenChange={ ( open ) => {
				if ( ! open ) {
					clearShapePreview();
				}
			} }
		>
			<Menu.SubmenuTriggerItem disabled={ ! editable }>
				<Menu.ItemLabel>Add shape</Menu.ItemLabel>
			</Menu.SubmenuTriggerItem>
			<Menu.Popover
				className="canvas-shape-picker"
				aria-label="Image shape"
				onPointerLeave={ clearShapePreview }
				onBlur={ ( event ) => {
					if (
						! event.currentTarget.contains( event.relatedTarget )
					) {
						clearShapePreview();
					}
				} }
			>
				{ IMAGE_SHAPES.map( ( { value, label } ) => (
					<Menu.Item
						key={ value }
						className="canvas-shape-picker__option"
						role="menuitemradio"
						aria-checked={ shape === value }
						disabled={ ! editable }
						hideOnClick
						onClick={ () => changeShape( clientId, value ) }
						onPointerEnter={ () => previewShape( clientId, value ) }
						onFocus={ () => previewShape( clientId, value ) }
					>
						<span className="canvas-shape-picker__label">
							<ShapeIcon shape={ value } />
							<span>{ label }</span>
						</span>
					</Menu.Item>
				) ) }
			</Menu.Popover>
		</CanvasSubmenu>
	);
}
